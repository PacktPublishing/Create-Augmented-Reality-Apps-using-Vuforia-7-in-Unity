# Vuforia_AR_Course
Basic Tools for AR Course on Udemy
Check out FULL video course here: https://www.udemy.com/create-augmented-reality-apps-using-vuforia-in-unity-sdk/?couponCode=AR_GITHUB


# Troubleshooting
Download Android SDK Tools https://www.dropbox.com/s/xlje4xci97iczgf/tools_r25.2.5-windows.zip?dl=0 
